"""Flight data analysis for BEAR-13 (Project Strato TV) and BEAR-14 (NUS TEH HALIA-1).
Source: RandomAerospace/BEAR13_FIRMWARE/FLIGHT DATA (aprs.fi exports). Times are UTC.
"""
import csv, re, json, math, sys
from datetime import datetime, timedelta
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = "/root/work/BEAR13_FIRMWARE/FLIGHT DATA"
OUT = "/root/work/report/figs"
STATS = {}

plt.rcParams.update({
    "font.family": "serif", "font.size": 9, "axes.labelsize": 9,
    "legend.fontsize": 8, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "axes.grid": True, "grid.alpha": 0.3, "figure.dpi": 150,
    "savefig.bbox": "tight", "lines.linewidth": 1.2,
})
C = {"alt": "#2a4d8f", "v": "#c0392b", "i": "#1e8449", "t": "#d35400", "b": "#7d3c98", "p": "#566573"}

RE_C = re.compile(r"(\d{6})Tx([CD])")
RE_T = re.compile(r"T:([+-]?\d+\.\d)")
RE_B = re.compile(r"B:([+-]?\d+\.\d)")
RE_P = re.compile(r"P:(\d{3,4})")
RE_V = re.compile(r"V:(\d+\.\d+)")
RE_I = re.compile(r"I:(\d+\.\d+)")


def parse(path, flight):
    rows = []
    with open(path, encoding="utf-8-sig", errors="replace") as f:
        rd = csv.reader(f)
        next(rd)
        for r in rd:
            if len(r) < 8:
                continue
            if flight == 13:
                # 'time' is HH:MM only; 'lasttime' carries the date. Rebuild from lasttime date + time.
                try:
                    lt = datetime.strptime(r[1], "%d/%m/%Y %H:%M")
                    hh, mm = map(int, r[0].split(":"))
                    t = lt.replace(hour=hh, minute=mm)
                    if t > lt + timedelta(hours=1):
                        t -= timedelta(days=1)
                except Exception:
                    continue
                comment = " ".join(r[7:12])
            else:
                t = datetime.strptime(r[0], "%Y-%m-%d %H:%M:%S")
                comment = r[7]
            m = RE_C.search(comment)
            if not m or not r[2] or not r[3] or not r[6]:
                continue
            d = dict(t=t, lat=float(r[2]), lon=float(r[3]), spd=float(r[4] or 0),
                     alt=float(r[6]), id=int(m.group(1)), page=m.group(2))
            for k, rx in (("T", RE_T), ("B", RE_B), ("P", RE_P), ("V", RE_V), ("I", RE_I)):
                mm_ = rx.search(comment)
                d[k] = float(mm_.group(1)) if mm_ else np.nan
            if flight == 13 and d["page"] == "C":
                d["B"] = np.nan  # BEAR-13 page C second field was the (unpopulated) external thermocouple
            rows.append(d)
    rows.sort(key=lambda d: (d["t"], d["id"]))
    return rows


def haversine(lat1, lon1, lat2, lon2):
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def slant(gs, lat, lon, alt_m):
    """Slant range (km) and elevation (deg) from ground station, spherical Earth."""
    R = 6371.0
    g = haversine(gs[0], gs[1], lat, lon)
    th = g / R
    h = alt_m / 1000.0
    r1, r2 = R, R + h
    d = math.sqrt(max(0.0, r1 ** 2 + r2 ** 2 - 2 * r1 * r2 * math.cos(th)))
    el = math.degrees(math.asin(max(-1.0, min(1.0, (r2 * math.cos(th) - r1) / d)))) if d > 0 else 90.0
    return g, d, el


def isa_pressure(h):
    """ISA pressure (hPa) for geometric-ish altitude h (m), up to 32 km."""
    if h <= 11000:
        return 1013.25 * (1 - 2.25577e-5 * h) ** 5.25588
    if h <= 20000:
        return 226.32 * math.exp(-1.5768852e-4 * (h - 11000))
    return 54.749 * (1 + (h - 20000) / 216650.0) ** -34.1632


def isa_alt(p):
    hs = np.linspace(0, 32000, 32001)
    ps = np.array([isa_pressure(h) for h in hs])
    return np.interp(p, ps[::-1], hs[::-1])


def phases(rows):
    alt = np.array([r["alt"] for r in rows])
    ib = int(np.argmax(alt))
    # launch: last sample at/below 150 m before sustained climb
    il = 0
    for k in range(ib, 0, -1):
        if alt[k] < 150:
            il = k
            break
    # landing: first sample after burst below 500 m, else last
    ild = len(rows) - 1
    for k in range(ib, len(rows)):
        if alt[k] < 500:
            ild = k
            break
    return il, ib, ild


def fit_rate(rows, a, b, lo, hi):
    ts = np.array([(r["t"] - rows[0]["t"]).total_seconds() for r in rows[a:b + 1]])
    hs = np.array([r["alt"] for r in rows[a:b + 1]])
    m = (hs > lo) & (hs < hi)
    if m.sum() < 3:
        return np.nan, np.nan
    k, c = np.polyfit(ts[m], hs[m], 1)
    resid = hs[m] - (k * ts[m] + c)
    r2 = 1 - resid.var() / hs[m].var()
    return k, r2


def analyse(flight, rows, gs):
    s = {}
    il, ib, ild = phases(rows)
    tl, tb, tld = rows[il]["t"], rows[ib]["t"], rows[ild]["t"]
    s["launch_utc"] = tl.strftime("%Y-%m-%d %H:%M")
    s["burst_utc"] = tb.strftime("%H:%M")
    s["last_utc"] = rows[-1]["t"].strftime("%H:%M")
    s["max_alt_m"] = rows[ib]["alt"]
    s["ascent_min"] = (tb - tl).total_seconds() / 60
    s["descent_min"] = (tld - tb).total_seconds() / 60
    k, r2 = fit_rate(rows, il, ib, 1000, rows[ib]["alt"] - 500)
    s["ascent_rate"] = k
    s["ascent_r2"] = r2
    s["ascent_rate_avg"] = (rows[ib]["alt"] - rows[il]["alt"]) / (tb - tl).total_seconds()
    # descent rate in the lower atmosphere (below 5 km), after burst
    kd, _ = fit_rate(rows, ib, len(rows) - 1, 600, 5000)
    s["descent_rate_low"] = kd
    kd2, _ = fit_rate(rows, ib, len(rows) - 1, 15000, rows[ib]["alt"] - 1000)
    s["descent_rate_high"] = kd2
    s["drift_km"] = haversine(rows[il]["lat"], rows[il]["lon"], rows[-1]["lat"], rows[-1]["lon"])
    s["max_gs_kmh"] = max(r["spd"] for r in rows[il:ib + 1])
    s["alt_at_max_gs"] = max(rows[il:ib + 1], key=lambda r: r["spd"])["alt"]
    # packet statistics over flight window (launch..last decoded)
    ids = sorted({r["id"] for r in rows[il:]})
    exp = ids[-1] - ids[0] + 1
    s["pkts_rx"] = len(ids)
    s["pkts_exp"] = exp
    s["pkt_rate"] = len(ids) / exp
    gaps = np.diff(ids) - 1
    s["max_gap_pkts"] = int(gaps.max())
    # sample interval
    dt = np.diff([(r["t"] - rows[0]["t"]).total_seconds() for r in rows[il:ild]])
    s["median_dt_s"] = float(np.median(dt[dt > 0])) if (dt > 0).any() else np.nan
    # power
    V = np.array([r["V"] for r in rows if not np.isnan(r["V"])])
    I = np.array([r["I"] for r in rows if not np.isnan(r["I"])])
    fl = [r for r in rows[il:ild + 1] if not np.isnan(r["V"])]
    s["V_start"] = fl[0]["V"]
    s["V_end"] = fl[-1]["V"]
    s["V_min"] = min(r["V"] for r in fl)
    If = np.array([r["I"] for r in fl])
    s["I_median"] = float(np.median(If))
    s["I_max"] = float(If.max())
    s["I_mean"] = float(If.mean())
    allp = [r for r in rows if not np.isnan(r["V"])]
    ts = np.array([(r["t"] - allp[0]["t"]).total_seconds() for r in allp])
    P = np.array([r["V"] * r["I"] for r in allp])
    E_Wh = np.trapezoid(P, ts) / 3600
    Q_mAh = np.trapezoid(np.array([r["I"] for r in allp]), ts) / 3.6
    s["E_Wh_logged"] = E_Wh
    s["Q_mAh_logged"] = Q_mAh
    s["logged_span_h"] = ts[-1] / 3600
    s["P_mean_W"] = E_Wh / (ts[-1] / 3600)
    # thermal
    Tc = [r for r in rows if r["page"] == "C" and not np.isnan(r["T"])]
    s["T_min"] = min(r["T"] for r in Tc)
    s["T_min_alt"] = min(Tc, key=lambda r: r["T"])["alt"]
    Bc = [r for r in rows if not np.isnan(r["B"])]
    if Bc:
        s["B_min"] = min(r["B"] for r in Bc[1:])
        s["B_max"] = max(r["B"] for r in Bc[1:])
    # baro
    pr = [r for r in rows[il:ild + 1] if r["page"] == "C" and not np.isnan(r["P"]) and r["P"] > 0]
    pa = np.array([r["alt"] for r in pr])
    pp = np.array([r["P"] for r in pr])
    ha = isa_alt(pp)
    err = ha - pa
    s["baro_n"] = len(pr)
    for lo, hi, tag in ((0, 10000, "0_10"), (10000, 20000, "10_20"), (20000, 40000, "20_up")):
        m = (pa >= lo) & (pa < hi)
        if m.any():
            s[f"baro_bias_{tag}"] = float(np.mean(err[m]))
            s[f"baro_rms_{tag}"] = float(np.sqrt(np.mean(err[m] ** 2)))
    s["P_min"] = float(pp.min())
    # ground-station geometry
    geo = [slant(gs, r["lat"], r["lon"], r["alt"]) for r in rows]
    s["max_slant_km"] = max(g[1] for g in geo[il:ild + 1])
    s["max_ground_km"] = max(g[0] for g in geo[il:ild + 1])
    return s, (il, ib, ild), geo


def tmin(rows, t0):
    return np.array([(r["t"] - t0).total_seconds() / 60 for r in rows])


# ----------------------------------------------------------------------------- run
f13 = parse(f"{ROOT}/FLIGHT13/aprsfi_export_9V1WP-11_20260327_110027_20260329_110027.csv", 13)
f14 = parse(f"{ROOT}/FLIGHT14/1p16zk.csv", 14)
GS = (1.29717, 103.76167)  # launch site; ground station assumed co-located

res = {}
for name, rows in (("f13", f13), ("f14", f14)):
    s, idx, geo = analyse(13 if name == "f13" else 14, rows, GS)
    res[name] = (rows, idx, geo)
    STATS[name] = s
    print(name, json.dumps(s, indent=1, default=str))

# ----------------------------------------------------------------------------- figures
import os
os.makedirs(OUT, exist_ok=True)

# 1. Altitude profiles
fig, ax = plt.subplots(figsize=(6.2, 2.8))
for name, col, lab in (("f13", C["alt"], "BEAR-13 (Strato TV)"), ("f14", C["v"], "BEAR-14 (TEH HALIA-1)")):
    rows, (il, ib, ild), _ = res[name]
    t0 = rows[il]["t"]
    seg = rows[il:]
    ax.plot(tmin(seg, t0), [r["alt"] / 1000 for r in seg], ".-", ms=2.5, color=col, label=lab)
ax.set_xlabel("Time since launch (min)")
ax.set_ylabel("GNSS altitude (km)")
ax.legend(loc="upper left")
fig.savefig(f"{OUT}/alt_profiles.pdf")
plt.close(fig)

# 2. Ground tracks
fig, ax = plt.subplots(figsize=(6.2, 3.2))
for name, col, lab in (("f13", C["alt"], "BEAR-13"), ("f14", C["v"], "BEAR-14")):
    rows, (il, ib, ild), _ = res[name]
    seg = rows[il:]
    ax.plot([r["lon"] for r in seg], [r["lat"] for r in seg], "-", color=col, label=lab, lw=1)
    ax.plot(rows[ib]["lon"], rows[ib]["lat"], "^", color=col, ms=6)
    ax.plot(seg[-1]["lon"], seg[-1]["lat"], "s", color=col, ms=5)
ax.plot(GS[1], GS[0], "k*", ms=10, label="Launch site (NUS)")
ax.set_xlabel("Longitude (°E)")
ax.set_ylabel("Latitude (°N)")
ax.set_aspect("equal")
ax.legend(loc="best", fontsize=7)
ax.text(0.01, 0.02, "▲ burst   ■ last decoded fix", transform=ax.transAxes, fontsize=7)
fig.savefig(f"{OUT}/ground_tracks.pdf")
plt.close(fig)

# 3. Power telemetry, both flights
fig, axs = plt.subplots(2, 1, figsize=(6.2, 4.6), sharex=False)
for ax, name, title in ((axs[0], "f13", "BEAR-13: 3S Li-Po, analogue VTx + comms board"),
                        (axs[1], "f14", "BEAR-14: 2S pack, UREx PDB with PTC heater")):
    rows, (il, ib, ild), _ = res[name]
    t0 = rows[il]["t"]
    pv = [r for r in rows if not np.isnan(r["V"])]
    tt = tmin(pv, t0)
    ax.plot(tt, [r["V"] for r in pv], color=C["v"], label="Bus voltage (V)")
    ax.set_ylabel("Voltage (V)", color=C["v"])
    ax2 = ax.twinx()
    ax2.plot(tt, [r["I"] for r in pv], color=C["i"], lw=0.9, label="Current (A)")
    ax2.set_ylabel("Current (A)", color=C["i"])
    ax2.grid(False)
    ax3 = ax.twinx()
    ax3.spines["right"].set_position(("outward", 38))
    ax3.plot(tmin(rows, t0), [r["alt"] / 1000 for r in rows], color=C["alt"], lw=0.8, alpha=0.6, ls="--")
    ax3.set_ylabel("Altitude (km)", color=C["alt"])
    ax3.grid(False)
    ax.set_title(title, fontsize=9)
    ax.axvline(0, color="k", lw=0.6, ls=":")
axs[1].set_xlabel("Time relative to launch (min)")
fig.tight_layout()
fig.savefig(f"{OUT}/power_both.pdf")
plt.close(fig)

# 4. BEAR-14 thermal: T (baro/internal), B (battery) vs time, heater state inferred from current
rows, (il, ib, ild), _ = res["f14"]
t0 = rows[il]["t"]
pc = [r for r in rows if r["page"] == "C" and (r["t"] - t0).total_seconds() > -600]
pd = [r for r in rows if r["page"] == "D"]
fig, ax = plt.subplots(figsize=(6.2, 3.0))
ax.plot(tmin(pc, t0), [r["T"] for r in pc], color=C["t"], label="Avionics bay (MS5611 die)")
ax.plot(tmin(pc, t0), [r["B"] for r in pc], color=C["b"], label="Battery (DS18B20)")
ax.axhspan(15, 20, color="0.85", alpha=0.6, label="Heater hysteresis band 15–20 °C")
ax.set_ylabel("Temperature (°C)")
ax.set_xlabel("Time since launch (min)")
ax2 = ax.twinx()
ax2.grid(False)
ax2.plot(tmin(rows, t0), [r["alt"] / 1000 for r in rows], color=C["alt"], lw=0.8, ls="--", alpha=0.6)
ax2.set_ylabel("Altitude (km)", color=C["alt"])
heat = [r for r in pd if r["I"] > 0.8]
ax.plot(tmin(heat, t0), [9] * len(heat), "|", color="k", ms=8, label="Heater on (I > 0.8 A)")
ax.legend(loc="upper right", fontsize=7)
ax.set_xlim(-10, tmin(rows, t0)[-1] + 2)
fig.savefig(f"{OUT}/thermal_f14.pdf")
plt.close(fig)

# heater duty statistic
Ivals = np.array([r["I"] for r in pd[pd.index(next(r for r in pd if r["t"] >= t0)):]])
STATS["f14"]["heater_on_frac"] = float((Ivals > 0.8).mean())
STATS["f14"]["I_heater_on_mean"] = float(Ivals[Ivals > 0.8].mean())
STATS["f14"]["I_heater_off_mean"] = float(Ivals[Ivals <= 0.8].mean())

# 5. Temperature vs altitude (ascent), both flights
fig, ax = plt.subplots(figsize=(3.6, 3.4))
for name, col, lab in (("f13", C["alt"], "BEAR-13 bay"), ("f14", C["t"], "BEAR-14 bay")):
    rows, (il, ib, ild), _ = res[name]
    seg = [r for r in rows[il:ib + 1] if r["page"] == "C" and not np.isnan(r["T"])]
    ax.plot([r["T"] for r in seg], [r["alt"] / 1000 for r in seg], ".-", ms=2, color=col, label=lab)
rows = res["f14"][0]
il, ib = res["f14"][1][:2]
seg = [r for r in rows[il:ib + 1] if r["page"] == "C" and not np.isnan(r["B"])]
ax.plot([r["B"] for r in seg], [r["alt"] / 1000 for r in seg], ".-", ms=2, color=C["b"], label="BEAR-14 battery")
ax.set_xlabel("Temperature (°C)")
ax.set_ylabel("Altitude (km), ascent only")
ax.legend(fontsize=7)
fig.savefig(f"{OUT}/temp_vs_alt.pdf")
plt.close(fig)

# 6. Barometer vs GNSS
fig, axs = plt.subplots(1, 2, figsize=(6.4, 3.0))
for name, col, lab in (("f13", C["alt"], "BEAR-13"), ("f14", C["v"], "BEAR-14")):
    rows, (il, ib, ild), _ = res[name]
    pr = [r for r in rows[il:ild + 1] if r["page"] == "C" and r["P"] > 0]
    pa = np.array([r["alt"] for r in pr]) / 1000
    pp = np.array([r["P"] for r in pr])
    axs[0].semilogx(pp, pa, ".", ms=3, color=col, label=lab)
    axs[1].plot(pa, (isa_alt(pp) / 1000 - pa) * 1000, ".", ms=3, color=col, label=lab)
hh = np.linspace(0, 32000, 200)
axs[0].semilogx([isa_pressure(h) for h in hh], hh / 1000, "k-", lw=0.8, label="ISA 1976")
axs[0].set_xlabel("MS5611 pressure (hPa)")
axs[0].set_ylabel("GNSS altitude (km)")
axs[0].legend(fontsize=7)
axs[1].axhline(0, color="k", lw=0.6)
axs[1].set_xlabel("GNSS altitude (km)")
axs[1].set_ylabel("ISA pressure altitude − GNSS (m)")
fig.tight_layout()
fig.savefig(f"{OUT}/baro.pdf")
plt.close(fig)

# 7. Pressure quantisation: altitude step per 1 hPa LSB
hh = np.linspace(0, 32000, 400)
dh = []
for h in hh:
    p = isa_pressure(h)
    dh.append(isa_alt(np.array([p - 0.5]))[0] - isa_alt(np.array([p + 0.5]))[0])
fig, ax = plt.subplots(figsize=(3.2, 2.6))
ax.semilogy(hh / 1000, dh, color=C["p"])
ax.set_xlabel("Altitude (km)")
ax.set_ylabel("Altitude per 1 hPa (m)")
fig.savefig(f"{OUT}/baro_quant.pdf")
plt.close(fig)
STATS["quant_1hPa_30km"] = float(np.interp(30000, hh, dh))
STATS["quant_1hPa_0km"] = float(dh[0])

# 8. BEAR-13 video link: slant range & elevation vs time, plus link budget
rows, (il, ib, ild), geo = res["f13"]
t0 = rows[il]["t"]
tt = tmin(rows, t0)
sl = np.array([g[1] for g in geo])
el = np.array([g[2] for g in geo])
# events from presentation: video degraded ~39 km LOS @ 20 km altitude, total loss ~46 km LOS
def first_cross(arr, thr, start):
    for k in range(start, len(arr)):
        if arr[k] >= thr:
            return k
    return None
k39 = first_cross(sl, 39, il)
k46 = first_cross(sl, 46, il)
STATS["f13"]["alt_at_39km"] = rows[k39]["alt"] if k39 else None
STATS["f13"]["el_at_39km"] = el[k39] if k39 else None
STATS["f13"]["alt_at_46km"] = rows[k46]["alt"] if k46 else None
STATS["f13"]["el_at_46km"] = el[k46] if k46 else None
STATS["f13"]["t_at_46km"] = tt[k46] if k46 else None

fig, ax = plt.subplots(figsize=(6.2, 2.8))
ax.plot(tt[il:], sl[il:], color=C["alt"], label="Slant range (km)")
ax.set_ylabel("Slant range (km)", color=C["alt"])
ax.set_xlabel("Time since launch (min)")
for k, lab, dx, ha in ((k39, "degradation\n(39 km)", -2, "right"), (k46, "total loss\n(46 km)", 2, "left")):
    if k:
        ax.axvline(tt[k], color="k", ls=":", lw=0.8)
        ax.text(tt[k] + dx, 2, lab, fontsize=7, ha=ha)
ax2 = ax.twinx()
ax2.grid(False)
ax2.plot(tt[il:], el[il:], color=C["t"], label="Elevation (°)")
ax2.set_ylabel("Elevation from GS (°)", color=C["t"])
fig.savefig(f"{OUT}/f13_geometry.pdf")
plt.close(fig)

# Link budget, 1280 MHz analogue FM video
f = 1280.0
Pt = 10 * math.log10(1500)  # dBm
Gt, Gr = 1.0, 10.0
B = 20e6
NF = 4.0
N = -174 + 10 * math.log10(B) + NF
d = np.linspace(5, 80, 300)
fspl = 20 * np.log10(d) + 20 * math.log10(f) + 32.44
Lmisc = 3.0  # cables/connectors + pointing, assumed
cnr = Pt + Gt + Gr - fspl - Lmisc - N
STATS["link"] = dict(Pt_dBm=Pt, N_dBm=N, fspl_50=20 * math.log10(50) + 20 * math.log10(f) + 32.44,
                     fspl_46=20 * math.log10(46) + 20 * math.log10(f) + 32.44,
                     fspl_39=20 * math.log10(39) + 20 * math.log10(f) + 32.44,
                     cnr_39=float(np.interp(39, d, cnr)), cnr_46=float(np.interp(46, d, cnr)),
                     Pr_46=Pt + Gt + Gr - (20 * math.log10(46) + 20 * math.log10(f) + 32.44) - Lmisc)
fig, ax = plt.subplots(figsize=(6.2, 2.8))
ax.plot(d, cnr, color=C["alt"], label="Predicted CNR, $G_t$ = 1 dBi, $L_{misc}$ = 3 dB")
ax.plot(d, cnr - 3, color=C["alt"], ls="--", lw=0.9, label="… with 3 dB polarisation/pattern loss")
ax.plot(d, cnr - 10, color=C["alt"], ls=":", lw=0.9, label="… with 10 dB pattern null")
ax.axhspan(0, 9, color=C["v"], alpha=0.12, label="Below FM threshold (≈9 dB CNR)")
ax.axvline(39, color="k", ls=":", lw=0.8)
ax.axvline(46, color="k", ls=":", lw=0.8)
ax.text(39.5, 26, "39 km", fontsize=7)
ax.text(46.5, 26, "46 km", fontsize=7)
ax.set_xlabel("Slant range (km)")
ax.set_ylabel("CNR in 20 MHz (dB)")
ax.set_ylim(-5, 30)
ax.legend(fontsize=7, loc="upper right")
fig.savefig(f"{OUT}/link_budget.pdf")
plt.close(fig)

# 9. Packet reception: received msg_id vs time with gaps, both flights
fig, ax = plt.subplots(figsize=(6.2, 2.4))
for name, col, lab in (("f13", C["alt"], "BEAR-13"), ("f14", C["v"], "BEAR-14")):
    rows, (il, ib, ild), _ = res[name]
    ids = sorted({r["id"] for r in rows[il:]})
    gaps = np.diff(ids) - 1
    ax.plot(ids[1:], gaps, ".", ms=3, color=col,
            label=f"{lab}: {STATS[name]['pkt_rate']*100:.0f}% of frames decoded")
ax.set_xlabel("Frame counter")
ax.set_ylabel("Frames lost before\nthis frame")
ax.legend(fontsize=7)
fig.savefig(f"{OUT}/packets.pdf")
plt.close(fig)

# 10. Ascent rate vs altitude (finite differences, smoothed)
fig, ax = plt.subplots(figsize=(3.2, 3.2))
for name, col, lab in (("f13", C["alt"], "BEAR-13"), ("f14", C["v"], "BEAR-14")):
    rows, (il, ib, ild), _ = res[name]
    seg = rows[il:ib + 1]
    ts = np.array([(r["t"] - seg[0]["t"]).total_seconds() for r in seg])
    hs = np.array([r["alt"] for r in seg])
    # bin by 1 km
    bins = np.arange(0, hs.max() + 1000, 2000)
    vr, hb = [], []
    for lo in bins[:-1]:
        m = (hs >= lo) & (hs < lo + 2000)
        if m.sum() >= 3 and np.ptp(ts[m]) > 0:
            vr.append(np.polyfit(ts[m], hs[m], 1)[0])
            hb.append((lo + 1000) / 1000)
    ax.plot(vr, hb, "o-", ms=3, color=col, label=lab)
ax.set_xlabel("Ascent rate (m/s)")
ax.set_ylabel("Altitude (km)")
ax.legend(fontsize=7)
fig.savefig(f"{OUT}/ascent_rate.pdf")
plt.close(fig)

json.dump(STATS, open("/root/work/analysis/stats.json", "w"), indent=1, default=str)
print(json.dumps({k: STATS[k] for k in ("link", "quant_1hPa_30km", "quant_1hPa_0km")}, indent=1))
print("heater", STATS["f14"]["heater_on_frac"], STATS["f14"]["I_heater_on_mean"], STATS["f14"]["I_heater_off_mean"])
print("f13 geo", {k: STATS["f13"][k] for k in ("alt_at_39km", "el_at_39km", "alt_at_46km", "el_at_46km", "t_at_46km")})
