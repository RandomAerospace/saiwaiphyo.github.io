import numpy as np, json, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.special import ellipk
plt.rcParams.update({"font.family":"serif","font.size":9,"axes.grid":True,"grid.alpha":0.3,"savefig.bbox":"tight"})
def K(k): return ellipk(k**2)
def cpwg(w, s, h, er, t=0.035):
    # thickness correction (Gupta): effective widening
    dw = (1.25*t/np.pi)*(1+np.log(4*np.pi*w/t)) if t>0 else 0
    we, se = w+dw, s-dw
    k = we/(we+2*se); kp = np.sqrt(1-k**2)
    k1 = np.tanh(np.pi*we/(4*h))/np.tanh(np.pi*(we+2*se)/(4*h)); k1p = np.sqrt(1-k1**2)
    q = (K(kp)/K(k))*(K(k1)/K(k1p))
    eeff = (1+er*q)/(1+q)
    Z = 60*np.pi/np.sqrt(eeff)/(K(k)/K(kp)+K(k1)/K(k1p))
    return Z, eeff
h, s, w0 = 0.2104, 0.5, 0.3421
res = {}
for er in (4.2, 4.4, 4.6):
    Z, e = cpwg(w0, s, h, er); res[f"er{er}"] = dict(Z=float(Z), eeff=float(e))
Z, e = cpwg(w0, s, h, 4.4)
for f in (144.39e6, 1280e6, 1575.42e6):
    lg = 3e8/f/np.sqrt(e)*1e3
    res[f"lg_{f/1e6:.0f}MHz_mm"] = float(lg); res[f"lg8_{f/1e6:.0f}MHz_mm"] = float(lg/8)
res["lam0_8_1280_mm"] = 3e8/1280e6*1e3/8
# sensitivity
ws = np.linspace(0.2, 0.6, 100)
fig, ax = plt.subplots(figsize=(3.4, 2.6))
for er, ls in ((4.2, "--"), (4.4, "-"), (4.6, ":")):
    ax.plot(ws, [cpwg(w, s, h, er)[0] for w in ws], ls, color="#2a4d8f", label=fr"$\varepsilon_r$ = {er}")
ax.axhline(50, color="k", lw=0.6); ax.axvline(w0, color="#c0392b", lw=0.8)
ax.text(w0+0.01, 70, "w = 0.342 mm\n(JLC solver)", fontsize=7, color="#c0392b")
ax.set_xlabel("Trace width w (mm), gap 0.5 mm, h = 0.210 mm"); ax.set_ylabel(r"$Z_0$ (Ω)"); ax.legend(fontsize=7)
fig.savefig("/root/work/report/figs/cpwg.pdf")
# sensitivity to gap
res["Z_gap0.3"] = float(cpwg(w0, 0.3, h, 4.4)[0]); res["Z_gap1.0"] = float(cpwg(w0, 1.0, h, 4.4)[0])
print(json.dumps(res, indent=1)); json.dump(res, open("cpwg.json","w"), indent=1)
