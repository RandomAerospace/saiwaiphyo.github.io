import csv, re, json, sys
out = {}
for name, bom, pcb in (("pdb", "power_stuff/POWER_DISTRIBUTION/UREX_PDB/UREX_PDB/production/bom.csv",
                         "power_stuff/POWER_DISTRIBUTION/UREX_PDB/UREX_PDB/UREX_PDB.kicad_pcb"),
                        ("comms", "COMMS-BOARD/Production/bom.csv", "COMMS-BOARD/COMMS_BOARD.kicad_pcb")):
    rows = list(csv.DictReader(open(bom, encoding="utf-8-sig")))
    q = sum(int(r["Quantity"]) for r in rows)
    lcsc = sum(1 for r in rows if (r.get("LCSC Part #") or r.get("LCSC") or "").strip())
    s = open(pcb).read()
    layers = re.findall(r'\(\d+ "([^"]+\.Cu)" signal', s) or re.findall(r'\(\d+ "(\w+\.Cu)"', s)
    vias = len(re.findall(r"\n\s*\(via\b", s))
    segs = len(re.findall(r"\n\s*\(segment\b", s)) + len(re.findall(r"\n\s*\(arc\b", s))
    fps = len(re.findall(r"\n\s*\(footprint\b", s))
    # board outline extents from Edge.Cuts gr_line/gr_rect/gr_arc
    xs, ys = [], []
    for m in re.finditer(r'\(gr_(?:line|rect|arc)\s+\(start ([-\d.]+) ([-\d.]+)\)(?:\s+\(mid [-\d.]+ [-\d.]+\))?\s+\(end ([-\d.]+) ([-\d.]+)\).*?\(layer "Edge\.Cuts"\)', s, re.S):
        xs += [float(m.group(1)), float(m.group(3))]
        ys += [float(m.group(2)), float(m.group(4))]
    thick = re.search(r"\(thickness ([\d.]+)\)", s)
    out[name] = dict(bom_lines=len(rows), parts=q, lcsc_lines=lcsc, cu_layers=sorted(set(layers)),
                     vias=vias, track_segs=segs, footprints=fps,
                     w=round(max(xs) - min(xs), 1) if xs else None, h=round(max(ys) - min(ys), 1) if ys else None,
                     thickness=thick.group(1) if thick else None)
    vals = [r["Value"] for r in rows]
    out[name]["ics"] = [v for v in vals if re.search(r"[A-Z]{2,}\d{2,}", v)][:40]
print(json.dumps(out, indent=1))
json.dump(out, open("analysis/boards.json", "w"), indent=1)
